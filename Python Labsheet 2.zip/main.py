"""Solutions for BCA Python Libraries and Applications — Lab Sheet 2."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

data = {
    "RollNo": [101, 102, 103, 104, 105, 106, 107, 108],
    "Name": ["Amit", "Neha", "Rahul", "Priya", "Rohan", "Kavya", "Arjun", "Simran"],
    "Department": ["BCA", "BCA", "MCA", "BCA", "MCA", "MCA", "BCA", "MCA"],
    "Age": [20, 21, 22, 20, 23, 22, 21, 24],
    "Marks": [85, 92, 67, 78, 88, 95, 55, 73],
}
df = pd.DataFrame(data)

def main():
    print("\\nQ1. Complete DataFrame\\n", df)
    print("\\nQ2. First 3 records\\n", df.head(3))
    print("\\nQ3. Last 2 records\\n", df.tail(2))
    print("\\nQ4. Number of rows and columns:", df.shape)
    print("\\nQ5. Column names:", df.columns.tolist())
    print("\\nQ6. Data types\\n", df.dtypes)
    print("\\nQ7. Name column\\n", df["Name"])
    print("\\nQ8. Name and Marks\\n", df[["Name", "Marks"]])

    print("\\nQ9. Marks > 80\\n", df[df["Marks"] > 80])
    print("\\nQ10. Marks < 70\\n", df[df["Marks"] < 70])
    print("\\nQ11. Marks between 70 and 90\\n", df[df["Marks"].between(70, 90)])
    print("\\nQ12. BCA students\\n", df[df["Department"] == "BCA"])
    print("\\nQ13. MCA students with marks > 80\\n",
          df[(df["Department"] == "MCA") & (df["Marks"] > 80)])
    print("\\nQ14. Age > 21\\n", df[df["Age"] > 21])

    print("\\nQ15. Average marks:", df["Marks"].mean())
    print("Q16. Maximum marks:", df["Marks"].max())
    print("Q17. Minimum marks:", df["Marks"].min())
    print("Q18. Median marks:", df["Marks"].median())
    print("Q19. Students scoring above 75:", (df["Marks"] > 75).sum())
    print("Q20. Average BCA marks:", df.loc[df["Department"] == "BCA", "Marks"].mean())
    print("Q21. Average MCA marks:", df.loc[df["Department"] == "MCA", "Marks"].mean())
    print("\\nQ22. Highest-scoring student\\n", df.loc[[df["Marks"].idxmax()]])

    df["Bonus"] = 5
    df["FinalMarks"] = df["Marks"] + df["Bonus"]
    df["Result"] = df["Marks"].apply(lambda mark: "Pass" if mark >= 40 else "Fail")

    def grade(mark):
        if mark >= 90:
            return "A+"
        if mark >= 80:
            return "A"
        if mark >= 70:
            return "B"
        if mark >= 60:
            return "C"
        return "D"

    df["Grade"] = df["Marks"].apply(grade)
    print("\\nQ23-Q26. DataFrame with Bonus, FinalMarks, Result, Grade\\n", df)

    print("\\nQ27. Sort marks highest to lowest\\n", df.sort_values("Marks", ascending=False))
    print("\\nQ28. Top 3 students\\n", df.nlargest(3, "Marks"))
    df["Rank"] = df["Marks"].rank(ascending=False, method="min").astype(int)
    print("\\nQ29. Rank column\\n", df[["Rank", "RollNo", "Name", "Marks"]].sort_values("Rank"))

    print("\\nQ30-Q33. Department group analysis\\n",
          df.groupby("Department")["Marks"].agg(["count", "mean", "max", "min"]))

    merit = df[["Rank", "RollNo", "Name", "Department", "Marks", "Grade", "Result"]]
    merit = merit.sort_values(["Marks", "RollNo"], ascending=[False, True])
    excel_path = OUTPUT_DIR / "student_merit_list.xlsx"
    merit.to_excel(excel_path, index=False)
    print("\\nChallenge: Merit list\\n", merit.to_string(index=False))
    print(f"\\nExcel merit list saved to: {excel_path}")

if __name__ == "__main__":
    main()
