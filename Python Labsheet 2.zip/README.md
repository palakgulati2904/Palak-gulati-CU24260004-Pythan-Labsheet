# BCA Python Libraries and Applications — Lab Sheet 2

This repository contains Python solutions for Lab Sheet 2 using **Pandas**.

## Included
- Q1–Q33: DataFrame display, selection, filtering, analysis, manipulation, ranking, and group analysis
- Challenge: create a merit list and export it to `student_merit_list.xlsx`
- Sample data matching the lab sheet

## Run locally
1. Install Python 3.10+.
2. Open this folder in VS Code.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run:
   ```bash
   python main.py
   ```

The script prints the answers to the terminal and saves the merit list Excel file in `outputs/`.

## GitHub upload
Create a repository on GitHub, then upload the extracted files. Alternatively, run these commands in this folder:
```bash
git init
git add .
git commit -m "Add BCA Pandas Lab Sheet 2 solutions"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
Replace the sample URL with your own repository URL.
